processGoogleToken({
    "newToken": "ChEI8LucmAYQhYSln535j9GdARI5AOwJ5LHBWgE9oCmLbV8M0Of4NoFYDI3TR9vmvIfDao4yadpm5aYozre0L5wIyXiPfSkEmMvnFinJ",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2022-08-25-09",
    "pucrd": ""
});