processGoogleToken({
    "newToken": "ChEI8LucmAYQhYSln535j9GdARI5AOwJ5LHTvky1gDZDFxFEU2-GODuFKSF15cCDS05UT18XiLT6WtV1xRKd524to0Ndax4yQCLSalZj",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "",
    "pucrd": ""
});